import React, { useEffect, useState } from 'react';

function App() {
  const [students, setStudents] = useState([]);
  const [name, setName] = useState('');
  const [branch, setBranch] = useState('');
  const [Roll, setRoll] = useState('');
  const [editId, setEditId] = useState('');

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = () => {
    fetch('http://localhost:5000/view')
      .then(response => response.json())
      .then(data => setStudents(data))
      .catch(error => console.error(error));
  };

  const addStudent = () => {
    const student = { name, branch, Roll };
    const url = editId ? `http://localhost:5000/update/${editId}` : 'http://localhost:5000/insert';
    const method = editId ? 'PUT' : 'POST';

    fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(student),
    })
      .then(response => response.json())
      .then(data => {
        if (editId) {
          setStudents(students.map(student => (student._id === editId ? data : student)));
          setEditId('');
        } else {
          setStudents([...students, data]);
        }
        setName('');
        setBranch('');
        setRoll('');
      })
      .catch(error => console.error(error));
  };

  

  const deleteStudent = id => {
    fetch(`http://localhost:5000/delete/${id}`, {
      method: 'DELETE',
    })
      .then(response => response.json())
      .then(data => {
        if (data.message) {
          const updatedStudents = students.filter(student => student._id !== id);
          setStudents(updatedStudents);
        } else {
          console.error(data.error);
        }
      })
      .catch(error => console.error(error));
  };

  const editStudent = student => {
    setName(student.name);
    setBranch(student.branch);
    setRoll(student.Roll);
    setEditId(student._id);
  };

  return (
    <div>
      <h1>Student App</h1>

      <h2>Add Student</h2>
      <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Name" />
      <input type="text" value={branch} onChange={e => setBranch(e.target.value)} placeholder="Branch" />
      <input type="text" value={Roll} onChange={e => setRoll(e.target.value)} placeholder="Roll" />
      <button onClick={addStudent}>{editId ? 'Update' : 'Add'}</button>

      <h2>Students</h2>
      <ul>
        {students.map(student => (
          <li key={student._id}>
            <span>Name: {student.name}</span>
            <span>Branch: {student.branch}</span>
            <span>Roll: {student.Roll}</span>
            <button onClick={() => editStudent(student)}>Edit</button>
            <button onClick={() => deleteStudent(student._id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
